package com.myclient.gui;

import com.myclient.MyClient;
import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.NumberSetting;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.Locale;

/** ClickGUI zbudowane z zwykłych przycisków Minecrafta (najmniej ryzyka przy zmianach API). */
public class ClickGuiScreen extends Screen {
    private static Category selectedCategory = Category.COMBAT;
    private static Module selectedModule;

    public ClickGuiScreen() {
        super(Component.literal("MyClient"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;

        // --- zakładki kategorii ---
        Category[] cats = Category.values();
        int tabW = 70;
        int x = cx - (cats.length * (tabW + 4) - 4) / 2;
        for (Category c : cats) {
            Component label = Component.literal(c.label);
            if (c == selectedCategory) label = Component.literal(c.label).withStyle(ChatFormatting.YELLOW);
            addRenderableWidget(Button.builder(label, btn -> {
                selectedCategory = c;
                selectedModule = null;
                rebuildWidgets();
            }).bounds(x, 20, tabW, 20).build());
            x += tabW + 4;
        }

        // --- lista modułów (lewa kolumna) ---
        int left = cx - 150;
        int y = 50;
        for (Module m : MyClient.MODULES.inCategory(selectedCategory)) {
            addRenderableWidget(Button.builder(label(m), btn -> {
                m.toggle();
                btn.setMessage(label(m));
            }).bounds(left, y, 110, 20).build());

            addRenderableWidget(Button.builder(Component.literal("..."), btn -> {
                selectedModule = m;
                rebuildWidgets();
            }).bounds(left + 114, y, 26, 20).build());
            y += 24;
        }

        // --- ustawienia wybranego modułu (prawa kolumna) ---
        if (selectedModule != null && selectedModule.category == selectedCategory) {
            int sx = cx + 10;
            int sy = 70;
            for (NumberSetting s : selectedModule.settings) {
                addRenderableWidget(Button.builder(Component.literal("-"), btn -> s.dec())
                        .bounds(sx + 100, sy, 20, 20).build());
                addRenderableWidget(Button.builder(Component.literal("+"), btn -> s.inc())
                        .bounds(sx + 124, sy, 20, 20).build());
                sy += 24;
            }
        }
    }

    private static Component label(Module m) {
        boolean on = m.isEnabled();
        return Component.literal(m.name + ": " + (on ? "ON" : "OFF"))
                .withStyle(on ? ChatFormatting.GREEN : ChatFormatting.RED);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);

        graphics.text(this.font, "MyClient", 6, 6, 0xFFFFFFFF, true);

        if (selectedModule != null && selectedModule.category == selectedCategory) {
            int sx = this.width / 2 + 10;
            graphics.text(this.font, selectedModule.name, sx, 54, 0xFFFFFF55, true);
            int sy = 70;
            for (NumberSetting s : selectedModule.settings) {
                String text = String.format(Locale.ROOT, "%s: %.2f", s.name, s.get());
                graphics.text(this.font, text, sx, sy + 6, 0xFFFFFFFF, true);
                sy += 24;
            }
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
