package com.myclient.mixin;

import com.myclient.util.PacketHooks;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Connection.class)
public abstract class ConnectionMixin {

    // FakeLag: pakiety wychodzące
    @Inject(method = "send(Lnet/minecraft/network/protocol/Packet;)V", at = @At("HEAD"), cancellable = true)
    private void myclient$onSend(Packet<?> packet, CallbackInfo ci) {
        if (PacketHooks.onSend(packet)) ci.cancel();
    }

    // Backtrack: pakiety przychodzące
    @Inject(method = "channelRead0(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/protocol/Packet;)V",
            at = @At("HEAD"), cancellable = true)
    private void myclient$onRead(ChannelHandlerContext ctx, Packet<?> packet, CallbackInfo ci) {
        if (PacketHooks.onReceive(packet)) ci.cancel();
    }
}
