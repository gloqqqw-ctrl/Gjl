package com.myclient.module.tp;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.NumberSetting;
import com.myclient.util.TpUtil;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;

/** Teleportuje do najbliższego innego gracza. Włączenie w GUI = jeden teleport. */
public class PlayerTp extends Module {
    private final NumberSetting maxDistance = add(new NumberSetting("Max dist", 60, 10, 200, 10));
    private final NumberSetting step = add(new NumberSetting("Step", 8, 2, 9, 1));

    public PlayerTp() {
        super("PlayerTP", Category.TP);
    }

    @Override
    protected void onEnable() {
        LocalPlayer p = mc.player;
        if (p != null && mc.level != null) {
            AbstractClientPlayer best = null;
            double bestDist = maxDistance.get();
            for (AbstractClientPlayer other : mc.level.players()) {
                if (other == p) continue;
                double d = p.distanceTo(other);
                if (d < bestDist) {
                    bestDist = d;
                    best = other;
                }
            }
            if (best != null) {
                TpUtil.teleportTo(mc, best.position(), step.get());
            }
        }
        setEnabled(false);
    }
}
