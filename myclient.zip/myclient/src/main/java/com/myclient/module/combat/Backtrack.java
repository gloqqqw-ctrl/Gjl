package com.myclient.module.combat;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.NumberSetting;

/** Opóźnia pakiety ruchu innych bytów (logika w PacketHooks). */
public class Backtrack extends Module {
    public final NumberSetting delay = add(new NumberSetting("Delay ms", 100, 20, 500, 10));

    public Backtrack() {
        super("Backtrack", Category.COMBAT);
    }
}
