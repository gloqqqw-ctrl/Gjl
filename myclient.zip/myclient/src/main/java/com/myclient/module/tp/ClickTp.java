package com.myclient.module.tp;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.NumberSetting;
import com.myclient.util.TpUtil;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Teleportuje w blok, na który patrzysz. Włączenie w GUI = jeden teleport. Klawisz G też działa. */
public class ClickTp extends Module {
    private final NumberSetting distance = add(new NumberSetting("Distance", 40, 5, 120, 5));
    private final NumberSetting step = add(new NumberSetting("Step", 8, 2, 9, 1));

    public ClickTp() {
        super("ClickTP", Category.TP);
    }

    @Override
    protected void onEnable() {
        teleport();
        setEnabled(false);
    }

    public void teleport() {
        LocalPlayer p = mc.player;
        if (p == null) return;

        HitResult hr = p.pick(distance.get(), 1.0F, false);
        if (hr.getType() != HitResult.Type.BLOCK) return;

        BlockHitResult bhr = (BlockHitResult) hr;
        BlockPos pos = bhr.getBlockPos().relative(bhr.getDirection());
        TpUtil.teleportTo(mc, new Vec3(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5), step.get());
    }
}
