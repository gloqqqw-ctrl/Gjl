package com.myclient.module.movement;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.NumberSetting;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

public class Speed extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 0.20, 0.05, 1.0, 0.05));

    public Speed() {
        super("Speed", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        LocalPlayer p = mc.player;
        if (p == null) return;
        if (p.isInWater() || p.isInLava() || p.onClimbable() || p.isFallFlying()) return;

        float forward = (mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0);
        float strafe = (mc.options.keyLeft.isDown() ? 1 : 0) - (mc.options.keyRight.isDown() ? 1 : 0);
        if (forward == 0 && strafe == 0) return;

        double yaw = Math.toRadians(p.getYRot());
        double sin = Math.sin(yaw);
        double cos = Math.cos(yaw);
        double mx = strafe * cos - forward * sin;
        double mz = forward * cos + strafe * sin;
        double len = Math.sqrt(mx * mx + mz * mz);
        if (len == 0) return;
        mx /= len;
        mz /= len;

        double s = speed.get();
        Vec3 v = p.getDeltaMovement();
        p.setDeltaMovement(mx * s, v.y, mz * s);
    }
}
