package com.myclient.module;

import com.myclient.module.combat.Backtrack;
import com.myclient.module.combat.FakeLag;
import com.myclient.module.combat.KillAura;
import com.myclient.module.movement.Speed;
import com.myclient.module.tp.ClickTp;
import com.myclient.module.tp.PlayerTp;
import com.myclient.module.world.AutoLever;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        modules.add(new KillAura());
        modules.add(new Backtrack());
        modules.add(new FakeLag());
        modules.add(new Speed());
        modules.add(new AutoLever());
        modules.add(new ClickTp());
        modules.add(new PlayerTp());
    }

    public List<Module> inCategory(Category category) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) {
            if (m.category == category) out.add(m);
        }
        return out;
    }

    public <T extends Module> T get(Class<T> type) {
        for (Module m : modules) {
            if (type.isInstance(m)) return type.cast(m);
        }
        return null;
    }

    public void tick() {
        for (Module m : modules) {
            if (m.isEnabled()) m.onTick();
        }
    }
}
