package com.myclient.module;

import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected final Minecraft mc = Minecraft.getInstance();

    public final String name;
    public final Category category;
    public final List<NumberSetting> settings = new ArrayList<>();
    private volatile boolean enabled;

    protected Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    protected NumberSetting add(NumberSetting setting) {
        settings.add(setting);
        return setting;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
    }

    protected void onEnable() {}

    protected void onDisable() {}

    /** Wywoływane co tick klienta, tylko gdy moduł jest włączony i gracz jest w świecie. */
    public void onTick() {}
}
