package com.myclient.module;

public class NumberSetting {
    public final String name;
    public final double min, max, step;
    private double value;

    public NumberSetting(String name, double value, double min, double max, double step) {
        this.name = name;
        this.value = value;
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public double get() {
        return value;
    }

    public void inc() {
        set(value + step);
    }

    public void dec() {
        set(value - step);
    }

    private void set(double v) {
        v = Math.round(v * 1000.0) / 1000.0;
        value = Math.max(min, Math.min(max, v));
    }
}
