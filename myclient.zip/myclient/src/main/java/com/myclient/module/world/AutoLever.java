package com.myclient.module.world;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.NumberSetting;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/** Automatycznie włącza wyłączone dźwignie w zasięgu ręki. */
public class AutoLever extends Module {
    private final NumberSetting reach = add(new NumberSetting("Reach", 4.5, 2.0, 6.0, 0.5));
    private final NumberSetting delayTicks = add(new NumberSetting("Delay ticks", 4, 1, 20, 1));
    private int cooldown;

    public AutoLever() {
        super("AutoLever", Category.WORLD);
    }

    @Override
    public void onTick() {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null) return;
        if (cooldown > 0) {
            cooldown--;
            return;
        }

        double rch = reach.get();
        int r = (int) Math.ceil(rch);
        Vec3 eye = p.getEyePosition();
        BlockPos base = p.blockPosition();

        for (BlockPos pos : BlockPos.betweenClosed(base.offset(-r, -r, -r), base.offset(r, r, r))) {
            BlockState state = mc.level.getBlockState(pos);
            if (!state.is(Blocks.LEVER) || state.getValue(BlockStateProperties.POWERED)) continue;

            Vec3 center = Vec3.atCenterOf(pos);
            if (eye.distanceToSqr(center) > rch * rch) continue;

            BlockHitResult hit = new BlockHitResult(center, Direction.UP, pos.immutable(), false);
            mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND, hit);
            p.swing(InteractionHand.MAIN_HAND);
            cooldown = (int) delayTicks.get();
            return;
        }
    }
}
