package com.myclient.module;

public enum Category {
    COMBAT("Combat"),
    MOVEMENT("Movement"),
    WORLD("World"),
    TP("TP");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
