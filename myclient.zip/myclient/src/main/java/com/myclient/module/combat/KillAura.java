package com.myclient.module.combat;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.NumberSetting;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public class KillAura extends Module {
    private final NumberSetting range = add(new NumberSetting("Range", 4.2, 2.0, 6.0, 0.1));

    public KillAura() {
        super("KillAura", Category.COMBAT);
    }

    @Override
    public void onTick() {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null) return;

        double r = range.get();
        Entity best = null;
        double bestDist = Double.MAX_VALUE;

        for (Entity e : mc.level.getEntities(p, p.getBoundingBox().inflate(r))) {
            if (!(e instanceof LivingEntity le) || !le.isAlive() || le instanceof ArmorStand) continue;
            if (e.isSpectator()) continue;
            if (!(e instanceof Player || e instanceof Enemy)) continue;
            double d = p.distanceTo(e);
            if (d > r || d >= bestDist) continue;
            best = e;
            bestDist = d;
        }
        if (best == null) return;

        face(p, best);

        if (p.getAttackStrengthScale(0.5F) >= 1.0F) {
            mc.gameMode.attack(p, best);
            p.swing(InteractionHand.MAIN_HAND);
        }
    }

    private static void face(LocalPlayer p, Entity target) {
        Vec3 eye = p.getEyePosition();
        Vec3 t = target.getBoundingBox().getCenter();
        double dx = t.x - eye.x;
        double dy = t.y - eye.y;
        double dz = t.z - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        p.setYRot(yaw);
        p.setXRot(pitch);
    }
}
