package com.myclient.module.combat;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.NumberSetting;

/** Zatrzymuje Twoje pakiety wychodzące i puszcza je paczką (logika w PacketHooks). */
public class FakeLag extends Module {
    public final NumberSetting delay = add(new NumberSetting("Delay ms", 200, 50, 1000, 50));

    public FakeLag() {
        super("FakeLag", Category.COMBAT);
    }
}
