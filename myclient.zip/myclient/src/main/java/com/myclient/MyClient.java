package com.myclient;

import com.mojang.blaze3d.platform.InputConstants;
import com.myclient.gui.ClickGuiScreen;
import com.myclient.module.ModuleManager;
import com.myclient.module.tp.ClickTp;
import com.myclient.util.PacketHooks;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public class MyClient implements ClientModInitializer {
    public static final String ID = "myclient";
    public static final ModuleManager MODULES = new ModuleManager();

    private static KeyMapping openGuiKey;
    private static KeyMapping clickTpKey;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(ID, "main"));

        openGuiKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.myclient.open_gui", InputConstants.Type.KEYSYM, InputConstants.KEY_RSHIFT, category));
        clickTpKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.myclient.click_tp", InputConstants.Type.KEYSYM, InputConstants.KEY_G, category));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openGuiKey.consumeClick()) {
                if (mc.gui.screen() == null) {
                    mc.gui.setScreen(new ClickGuiScreen());
                }
            }
            while (clickTpKey.consumeClick()) {
                ClickTp tp = MODULES.get(ClickTp.class);
                if (tp != null) tp.teleport();
            }

            if (mc.player == null || mc.level == null) {
                PacketHooks.clear();
                return;
            }

            PacketHooks.tick();
            MODULES.tick();
        });
    }
}
