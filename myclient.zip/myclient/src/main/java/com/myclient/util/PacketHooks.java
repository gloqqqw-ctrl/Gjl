package com.myclient.util;

import com.myclient.MyClient;
import com.myclient.module.combat.Backtrack;
import com.myclient.module.combat.FakeLag;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.common.ServerboundKeepAlivePacket;
import net.minecraft.network.protocol.common.ServerboundPongPacket;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundEntityPositionSyncPacket;
import net.minecraft.network.protocol.game.ClientboundMoveEntityPacket;
import net.minecraft.network.protocol.game.ClientboundTeleportEntityPacket;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

/** Kolejki opóźnionych pakietów dla FakeLag (wychodzące) i Backtrack (przychodzące). */
public final class PacketHooks {
    private record Delayed(Packet<?> packet, long time) {}

    private static final Queue<Delayed> OUTGOING = new ConcurrentLinkedQueue<>();
    private static final Queue<Delayed> INCOMING = new ConcurrentLinkedQueue<>();
    private static volatile boolean bypass;

    private PacketHooks() {}

    /** @return true = anuluj wysłanie (pakiet trafił do kolejki). */
    public static boolean onSend(Packet<?> packet) {
        if (bypass) return false;
        FakeLag lag = MyClient.MODULES.get(FakeLag.class);
        if (lag == null || !lag.isEnabled()) return false;
        if (Minecraft.getInstance().player == null) return false;
        if (packet.type().flow() != PacketFlow.SERVERBOUND) return false;
        if (packet instanceof ServerboundKeepAlivePacket || packet instanceof ServerboundPongPacket) return false;

        OUTGOING.add(new Delayed(packet, System.currentTimeMillis()));
        return true;
    }

    /** @return true = anuluj natychmiastowe przetworzenie (pakiet trafił do kolejki). */
    public static boolean onReceive(Packet<?> packet) {
        Backtrack bt = MyClient.MODULES.get(Backtrack.class);
        if (bt == null || !bt.isEnabled()) return false;
        if (Minecraft.getInstance().player == null) return false;

        if (packet instanceof ClientboundMoveEntityPacket
                || packet instanceof ClientboundTeleportEntityPacket
                || packet instanceof ClientboundEntityPositionSyncPacket) {
            INCOMING.add(new Delayed(packet, System.currentTimeMillis()));
            return true;
        }
        return false;
    }

    /** Wołane co tick z głównego wątku: puszcza pakiety, którym minął czas (lub wszystkie, gdy moduł wyłączony). */
    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        ClientPacketListener conn = mc.getConnection();
        if (conn == null) {
            clear();
            return;
        }
        long now = System.currentTimeMillis();

        Backtrack bt = MyClient.MODULES.get(Backtrack.class);
        boolean btOn = bt != null && bt.isEnabled();
        long btDelay = btOn ? (long) bt.delay.get() : 0;
        Delayed d;
        while ((d = INCOMING.peek()) != null && (!btOn || now - d.time() >= btDelay)) {
            INCOMING.poll();
            handleIncoming(conn, d.packet());
        }

        FakeLag lag = MyClient.MODULES.get(FakeLag.class);
        boolean lagOn = lag != null && lag.isEnabled();
        Delayed first = OUTGOING.peek();
        if (first != null && (!lagOn || now - first.time() >= (long) lag.delay.get())) {
            bypass = true;
            try {
                Delayed out;
                while ((out = OUTGOING.poll()) != null) {
                    conn.send(out.packet());
                }
            } finally {
                bypass = false;
            }
        }
    }

    public static void clear() {
        OUTGOING.clear();
        INCOMING.clear();
    }

    @SuppressWarnings("unchecked")
    private static void handleIncoming(ClientPacketListener conn, Packet<?> packet) {
        try {
            ((Packet<ClientGamePacketListener>) packet).handle(conn);
        } catch (Exception ignored) {
            // pakiet mógł dotyczyć bytu, którego już nie ma
        }
    }
}
