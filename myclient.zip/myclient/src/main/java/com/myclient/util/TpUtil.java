package com.myclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.world.phys.Vec3;

public final class TpUtil {
    private TpUtil() {}

    /** Teleport przez serię pakietów pozycji (max `step` bloków na pakiet). */
    public static void teleportTo(Minecraft mc, Vec3 target, double step) {
        LocalPlayer p = mc.player;
        ClientPacketListener conn = mc.getConnection();
        if (p == null || conn == null) return;

        Vec3 from = p.position();
        Vec3 delta = target.subtract(from);
        int steps = Math.max(1, (int) Math.ceil(delta.length() / step));

        for (int i = 1; i <= steps; i++) {
            Vec3 pos = from.add(delta.scale((double) i / steps));
            conn.send(new ServerboundMovePlayerPacket.Pos(pos.x, pos.y, pos.z, false, false));
        }
        p.setPos(target.x, target.y, target.z);
        p.setDeltaMovement(Vec3.ZERO);
    }
}
